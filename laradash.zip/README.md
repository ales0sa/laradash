# laradash
composer require ales0sa/laradash

php artisan dashboard:init

yarn

yarn prod