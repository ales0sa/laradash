@inject('cf', '\Ales0sa\Laradash\Models\ConfigVar')
