<?php

return [
	'message'                => 'mensaje',
    'token_mismatch'         => 'El formulario ha expirado debido a la inactividad. Inténtalo de nuevo',
    'token_mismatch_comment' => 'Este mensaje puede aparecer cuando el formulario tenga mucho tiempo abierto y haya expirado, o estuvo interactuando con otras pestañas cuando este formulario ya había sido abierto, es un mecanismo de seguridad, intente nuevamente'
];
