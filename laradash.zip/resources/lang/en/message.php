<?php

return [
	'message'                => 'message',
    'token_mismatch'         => 'The form has expired due to inactivity. Please try again',
    'token_mismatch_comment' => 'This message may appear when the form has been open for a long time and has expired, or was interacting with other tabs when this form had already been opened, it is a security mechanism, try again'
];
