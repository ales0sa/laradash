<template>
    <div>

        Laravel Log

    </div>
</template>
<script>
export default {
    
}
</script>