<template>
	<div class="layout-footer">
		<span class="footer-text" style="margin-right: 5px"></span>
		&copy 2021
		<span class="footer-text" style="margin-left: 5px"></span>
	</div>
</template>

<script>
	export default {
		name: "AppFooter"
	}
</script>

<style scoped>

</style>