require('./../../vendor/ales0sa/laradash/resources/js/dashboard')
