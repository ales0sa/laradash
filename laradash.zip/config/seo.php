<?php
return [
    'default'   => 'Por defecto en todas las secciones',
    'home'      => 'Principal',
    'rubros'    => 'Producto - Rubros',
    'empresa'   => 'Empresa',
    'producto'  => 'Productos',
    'novadades' => 'Novadades',
    'contacto'  => 'Contacto',
];